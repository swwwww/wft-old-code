require('UIWebView,UIColor,UIDevice');
defineClass('DyWebViewTableViewCell', {
    
    setConstraints: function() {
        var web = self.webView();
        web.setAutoresizingMask(1|4|8|32);
        if (UIDevice.currentDevice().systemVersion().floatValue() >= 7.0) {
            self.super().setConstraints();
            var web = self.webView();
            var bg = self.bgView();
            web.mas__makeConstraints(block('MASConstraintMaker*', function(make) {
                make.edges().equalTo()(bg);
            }));
        }
    },
});