require('UIColor,UIView,UITextField,UIFont,UIButton');
defineClass('DyCashCouponMineConvertCell', {
    initView: function() {
        self.super().initView();
        self.setBackgroundColor(UIColor.clearColor());
        self.bgView().setBackgroundColor(UIColor.clearColor());
        self.setSelectionStyle(0);
        self.setTop(10);
        var view = UIView.alloc().initWithFrame({x:0,y:0,width:18,height:18})
        _leftView = view;
        _leftView.setBackgroundColor(UIColor.clearColor());
        self.setCodeText(UITextField.alloc().init());
        self.codeText().setBackgroundColor(UIColor.whiteColor());
        self.codeText().setPlaceholder("可兑换传播码");
        self.codeText().setBorderStyle(0);
        self.codeText().layer().setCornerRadius(15);
        self.codeText().layer().setBorderColor(UIColor.appGray160Color().CGColor());
        self.codeText().layer().setBorderWidth(0.6);
        self.codeText().setLeftView(_leftView);
        self.codeText().setLeftViewMode(3);
        self.codeText().setFont(UIFont.systemFontOfSize(14));
        self.codeText().setTextColor(UIColor.appGray150Color());
        self.codeText().setDelegate(self);
        self.contentView().addSubview(self.codeText());
        self.setConvertButton(UIButton.alloc().init());
        self.convertButton().setTitle_forState("兑换", 0);
        self.convertButton().titleLabel().setTextColor(UIColor.whiteColor());
        self.convertButton().setFont(UIFont.systemFontOfSize(15));
        self.convertButton().setBackgroundColor(UIColor.appRedColor());
        self.convertButton().layer().setCornerRadius(15);
        self.convertButton().addTarget_action_forControlEvents(self, "convertButtonClick:", 7);
        self.contentView().addSubview(self.convertButton());
    },
})