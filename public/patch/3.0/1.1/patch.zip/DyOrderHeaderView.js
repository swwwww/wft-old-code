defineClass('DyOrderHeaderView', {
    setConstraints: function() {
        self.super().setConstraints();
        var bg = self.bgView();
        var timetitle = self.timeTitleLabel();
         var ordertitle = self.orderTitleLabel();
         var order = self.orderLabel();
         var time = self.timeLabel();
        timetitle.mas__makeConstraints(block('MASConstraintMaker*', function(make) {
            make.left().equalTo()(bg).offset()(14);
            make.width().equalTo()((65));
            make.top().equalTo()(bg).offset()(9);
        }));
        
        time.mas__makeConstraints(block('MASConstraintMaker*', function(make) {
            make.left().equalTo()(timetitle.mas__right()).offset()(10);
            make.top().equalTo()(timetitle);
            make.right().equalTo()(bg).offset()(-14);
        }));
        
 

    ordertitle.mas__makeConstraints(block('MASConstraintMaker*', function(make) {
        make.left().equalTo()(timetitle);
        // make.height().equalTo()((12));
        make.width().equalTo()((65));
        make.bottom().equalTo()(bg).offset()(-9).priorityMedium()();
        make.top().equalTo()(timetitle.mas__bottom()).offset()(9);
            make.top().equalTo()(time.mas__bottom()).offset()(9).priorityMedium();
        
    }));
           order.mas__makeConstraints(block('MASConstraintMaker*', function(make) {
            make.left().equalTo()(ordertitle.mas__right()).offset()(10);
            make.top().equalTo()(ordertitle);
            make.right().equalTo()(bg).offset()(-14); 
            make.bottom().equalTo()(bg).offset()(-9);
        }));
},
});