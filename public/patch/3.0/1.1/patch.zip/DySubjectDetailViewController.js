require('DySubjectPlaceEntity,DySubjectGoodEntity,JPEngine').addExtensions(['JPMacroSupport']);
defineClass('DySubjectDetailViewController', {
    configCell_atIndexPath: function(cell, indexPath) {
        var header = self.valueForKey("_sectionHeader");
        var detail = self.valueForKey("_sectionDetail");
        var sortA = self.valueForKey("_detailCellSortA");
        var detailsort = self.valueForKey("_detailCellSort");
        var sectionList = self.valueForKey("_sectionList");
        var detailCellType = self.valueForKey("_detailCellType");
        if (indexPath.section() == header) {
            var tableViewCell = cell;
            tableViewCell.setEntity(self.detailEntity());
        } else if (indexPath.section() == detail) {
            if (indexPath.row() == detailCellType) {
                var tableViewCell = cell;
                    tableViewCell.setDelegate(self);
                    var value = self.segmentValue();
                    if (value >= 0 ) {
                        if (value < 100) {
                            tableViewCell.segmentedControl().setSelectedSegmentIndex(value);
                        }
                    }  
            } else if (indexPath.row() == detailsort) {
                var tableViewCell =  cell;             
                    tableViewCell.setDelegate(self);
                    tableViewCell.setSelectedIndex(self.sortValue());
            } else if (indexPath.row() == sortA) {
                var tableViewCell =  cell;            
                    tableViewCell.setDelegate(self);
                    tableViewCell.setSelectedIndex(self.sortValue());        
            }
        } else if (indexPath.section() == sectionList) {
            var tableViewCell =  cell;
            var top = 8;
            if (indexPath.row == 0) {
                top = 8;
            } else {
                top = 4;
            }
            tableViewCell.setTop(top);
            if (self.segmentValue() == 0) {
                var entity = DySubjectPlaceEntity.alloc().init();
                if (indexPath.row() < self.placeEntityList().count()) {
                    entity = self.placeEntityList().objectAtIndex(indexPath.row());
                }
                tableViewCell.setPlaceEntity(entity);
            } else {
                var entity = DySubjectGoodEntity.alloc().init();
                if (indexPath.row() < self.goodEntityList().count()) {
                    entity = self.goodEntityList().objectAtIndex(indexPath.row());
                }
                tableViewCell.setGoodEntity(entity);
            }
        }
    },
});