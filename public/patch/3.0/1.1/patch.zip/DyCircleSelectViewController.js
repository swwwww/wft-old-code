require('DyUserSpace');
defineClass('DyCircleSelectViewController', {
    viewWillAppear: function(animated) {
        self.super().viewWillAppear(animated);
        var userId = self.uid();
        var theid = DyUserSpace.getInstance().userId()
        if (!userId) {
            self.setUid(theid);
        }
        console.log('_uid',theid);
    },
});