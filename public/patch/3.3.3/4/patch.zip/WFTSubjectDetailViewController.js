// V3.3.3 v3.3.4 专题相信 无法加载第二页数据
require('MBProgressHUD,GRNetworkResponse');
defineClass('WFTSubjectDetailViewController', {
            getMoreTableView: function() {
            var tableView = self.valueForKey("_tableView");
            var slf = self;
            self.getSubjectsGetMore_success_failure(YES, block('GRNetworkResponse*', function(response) {
                                                               slf.updateTableView(block(function() {
                                                                                         var hasMore = slf.valueForKey("_hasMore");
                                                                                         if (hasMore == YES) {
                                                                                         tableView.mj__footer().endRefreshing();
                                                                                         } else {
                                                                                         tableView.mj__footer().endRefreshingWithNoMoreData();
                                                                                         }
                                                                                         }));
                                                               }), block('NSString*', function(message) {
                                                                         MBProgressHUD.hideDurationProgressHUDWithFailedMessage(message);
                                                                         tableView.mj__footer().endRefreshing();
                                                                         }));
            },
            });
