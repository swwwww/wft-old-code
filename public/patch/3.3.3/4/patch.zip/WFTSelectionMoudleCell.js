// v3.3.4 webviewcontroller没有携带p参数
require('WFTStatisticsManager,WFTBaseRouter,NSString');
defineClass('WFTSelectionMoudleCell', {
    handleClick: function(sender) {
        var tag = sender.tag();
        var viewController = self.valueForKey("_viewController");
        var entity = self.moduleArray().objectAtIndex(tag - 1000);
        var type = entity.type();
        var label = NSString.stringWithFormat("%zd",tag - 1000 + 11);
        var title = entity.title().mutableCopy();
        WFTStatisticsManager.shareInstance().logEvent_eventLabel(label," ");
        if (type == 6) {
          title = null;
        }
        WFTBaseRouter.shareInstance().delegate().base_goWithType_id_url_title(viewController,type,entity.id(),entity.url(), title);
    },
});
