defineClass('WFTPlayApplyViewController',['lastNumber','temp'],{
            viewDidAppear: function(animated) {
            self.super().viewDidAppear(animated);
            self.setLastNumber(self.entity().join__number());
            },
            
            playApplySchemeCell_didUpdateNumber: function(sender, number) {
            var index = sender.tag() - 10000;
            var memberentity = self.entity().members().objectAtIndex(index);
            self.entity().setJoin__number(self.lastNumber() - number);
            memberentity.setSelect__num(number);
            self.updateToolView();
            },
            viewDidLoad: function() {
            self.super().viewDidLoad();
            self.enablePullToRefresh();
            self.view().addSubview(self.toolView());
            self.setConstraints();
            self.tableView().mj__header().beginRefreshing();
            },
            });
