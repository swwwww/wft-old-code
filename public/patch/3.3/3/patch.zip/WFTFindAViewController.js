defineClass('WFTFindAViewController', {
    viewWillAppear: function(animated) {
        self.super().viewWillAppear(animated);
        self.navigationItem().setRightBarButtonItem(null);
    },
});
