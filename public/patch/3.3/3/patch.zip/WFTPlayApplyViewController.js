defineClass('WFTPlayApplyViewController', {
viewDidLoad: function() {
       self.super().viewDidLoad();
       self.enablePullToRefresh();
       self.view().addSubview(self.toolView());
       self.setConstraints();
       self.tableView().mj__header().beginRefreshing();
   },
});
