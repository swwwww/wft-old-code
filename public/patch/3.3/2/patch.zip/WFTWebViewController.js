require('WFTPlayDetailViewController');
defineClass('WFTWebViewController', {
            processUrl: function(url) {
            console.log(url);
            var enableProcessUrl = self.enableProcessUrl();
            if (!enableProcessUrl) {
            return YES;
            }
            var recordstartrange = url.rangeOfString("recordstart$");
            if (recordstartrange.length > 0) {
            self.addRecord();
            return NO;
            }
            var websharerange = url.rangeOfString("webshare$");
            if (websharerange.length > 0) {
            self.startShareFromWebWithUrl(url);
            return NO;
            }
            var bind_phonerange = url.rangeOfString("bind_phone$");
            if (bind_phonerange.length > 0) {
            self.startBindPhone();
            return NO;
            }
            var reg_userrange = url.rangeOfString("reg_user$");
            if (reg_userrange.length > 0) {
            self.startRegUser();
            return NO;
            }
            var user_loginrange = url.rangeOfString("user_login$");
            if (user_loginrange.length > 0) {
            self.startUserLogin();
            return NO;
            }
            var scan_qrcoderange = url.rangeOfString("scan_qrcode$");
            if (scan_qrcoderange.length > 0) {
            self.startScanQrcode();
            return NO;
            }
            var game_inforange = url.rangeOfString("game_info$$id=");
            if (game_inforange.length > 0) {
            var id = url.substringFromIndex((game_inforange.location + game_inforange.length));
            if (id.length() > 0) {
            self.startGameInfoWithId(id);
            return NO;
            }
            }
            
            var special_inforange = url.rangeOfString("special_info$$id=");
            if (special_inforange.length > 0) {
            var id = url.substringFromIndex((special_inforange.location + special_inforange.length));
            if (id.length() > 0) {
            self.startSpecialInfoWithId(id);
            return NO;
            }
            }
            
            var shop_inforange = url.rangeOfString("shop_info$$id=");
            if (shop_inforange.length > 0) {
            var id = url.substringFromIndex((shop_inforange.location + shop_inforange.length));
            if (id.length() > 0) {
            self.startShopInfoWithId(id);
            return NO;
            }
            }
            
            var exchangerange = url.rangeOfString("exchange$$");
            if (exchangerange.length > 0) {
            self.startIntegralSecKill();
            return NO;
            }
            
            var integralrange = url.rangeOfString("integral$$id=");
            if (integralrange.length > 0) {
            var id = url.substringFromIndex((integralrange.location + integralrange.length));
            if (id.length() > 0) {
            self.startIntegralTaskWithId(id);
            return NO;
            }
            }
            
            var kids_playrange = url.rangeOfString("kids_play$$id=");
            if (kids_playrange.length > 0) {
            var id = url.substringFromIndex((kids_playrange.location + kids_playrange.length));
            if (id.length() > 0) {
            var play = WFTPlayDetailViewController.alloc().init();
            play.setPlayId(id);
            play.setHidesBottomBarWhenPushed(YES);
            self.navigationController().pushViewController_animated(play, YES);
            return NO;
            }
            }
            return YES;
            },
            });
