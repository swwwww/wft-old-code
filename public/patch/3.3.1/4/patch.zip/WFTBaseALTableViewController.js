require('SDWebImagePrefetcher');
defineClass('WFTBaseALTableViewController', {
            viewDidAppear: function(animated) {
            self.super().viewDidAppear(animated);
            SDWebImagePrefetcher.sharedImagePrefetcher().setMaxConcurrentDownloads(100);
            },
            });
