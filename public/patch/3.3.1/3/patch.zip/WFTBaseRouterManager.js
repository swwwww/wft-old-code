defineClass('WFTBaseRouterManager', {
    loginSuccessInLoginViewController: function(viewController) {
        if (self.loginBlock()) {
            self.loginBlock()(YES);
        }
    },
});
