require('UIImage');
defineClass('WFTPlaceCellGoodsView', {
    updateForEntity: function(entity) {
      var titleLabel = self.titleLabel();
        titleLabel.setText(entity.ticket__name());
        var realPrice = entity.price();
        var statusLabel = self.statusLabel();
        var priceValueLabel = self.priceValueLabel();
        var priceTailLabel = self.priceTailLabel();
        var priceSignLabel = self.priceSignLabel();
        var avatarImageView = self.avatarImageView();
        if (entity.type() == 1) {
            self.avatarImageView().setImage(UIImage.imageNamed("search_title_goods"));
            statusLabel.setHidden(NO);
            var status = "";
            if (entity.status() == 1) {
                status = "未开始";
            } else {
                status = "已售罄";
            }
            statusLabel.setText(status);
            var hidden = YES;
            if (entity.status() == 0) {
                hidden = NO;
            } else {
                hidden = YES;
            }
            priceValueLabel.setText(realPrice);
            statusLabel.setHidden(!hidden);
            priceSignLabel.setHidden(hidden);
            priceValueLabel.setHidden(hidden);
            priceTailLabel.setHidden(hidden);
        } else {
            avatarImageView.setImage(UIImage.imageNamed("search_title_play"));
            if (entity.price().length()) {
                priceSignLabel.setHidden(NO);
                priceValueLabel.setHidden(NO);
                priceTailLabel.setHidden(NO);
                priceValueLabel.setText(realPrice);
            } else {
                priceSignLabel.setHidden(YES);
                priceValueLabel.setHidden(YES);
                priceTailLabel.setHidden(YES);
            }
            statusLabel.setHidden(YES);
        }
    },
});
