defineClass('WFTFindViewController', {
    viewWillAppear: function(animated) {
        self.super().viewWillAppear(animated);
        self.navigationItem().setRightBarButtonItem(null);
    },
});
