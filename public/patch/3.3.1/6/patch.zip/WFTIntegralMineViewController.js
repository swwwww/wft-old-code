require('WFTBaseRouter,NSString,WFTURL');
defineClass('WFTIntegralMineViewController', {
    inviteButtonDidClick: function(sender) {
        WFTBaseRouter.shareInstance().delegate().base_goWebWithUrl_title_enableParameterString_enableProcessUrl(self, NSString.stringWithFormat("%@/webinvite", WFTURL.baseDomain()), "邀请有礼", YES, YES);
    },
});
