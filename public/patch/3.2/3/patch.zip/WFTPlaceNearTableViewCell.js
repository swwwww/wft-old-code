defineClass('WFTPlaceNearTableViewCell', {
    setConstraints: function() {
        self.super().setConstraints();
        var bg = self.bgView();
        var otherBgView = self.otherBgView();
         var nameLabel = self.nameLabel();
         var contentLabel = self.contentLabel();
         var distanceImageView = self.distanceImageView();
         var distanceLabel = self.distanceLabel();
         otherBgView.mas__makeConstraints(block('MASConstraintMaker*', function(make) {
             make.left().equalTo()(bg).offset()(10);
             make.top().bottom().equalTo()(bg);
             make.right().equalTo()(bg).offset()(-10);
         }));
         nameLabel.mas__makeConstraints(block('MASConstraintMaker*', function(make) {
             make.top().equalTo()(otherBgView).offset()(4);
             make.left().equalTo()(otherBgView).offset()(20);
             make.right().lessThanOrEqualTo()(distanceLabel.mas__left()).offset()(-4);
         }));
         contentLabel.mas__makeConstraints(block('MASConstraintMaker*', function(make) {
             make.left().equalTo()(nameLabel);
             make.right().lessThanOrEqualTo()(distanceLabel.mas__left()).offset()(-4);
             make.top().equalTo()(nameLabel.mas__bottom()).offset()(4);
             make.bottom().equalTo()(otherBgView).offset()(-4);
         }));
         distanceLabel.mas__makeConstraints(block('MASConstraintMaker*', function(make) {
             make.centerY().equalTo()(nameLabel);
             make.right().equalTo()(distanceImageView.mas__centerX()).offset()(-10 - 10);
         }));
         distanceImageView.mas__makeConstraints(block('MASConstraintMaker*', function(make) {
             make.centerY().equalTo()(nameLabel);
             make.centerX().equalTo()(otherBgView.mas__right()).offset()(-13 - 10);
         }));
        nameLabel.setContentCompressionResistancePriority_forAxis(250, 0);
        contentLabel.setContentCompressionResistancePriority_forAxis(250, 0)
},
});
