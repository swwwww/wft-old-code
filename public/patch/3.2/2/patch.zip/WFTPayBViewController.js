require('WFTCashCouponMineEntity','WFTOrderCommenEntity','WFTPayToolView','NSString');
defineClass('WFTPayBViewController', {
    updateToolView: function() {
    var price;
    var entity = self.entity();
    var toolView = self.toolView();
    var cashcouponEntity = self.valueForKey("_cashCouponEntity");
    if(!entity.cash__coupon__id().isEqualToString(cashcouponEntity.id())) {
        price = entity.price().floatValue() - cashcouponEntity.price().floatValue() + entity.cash__coupon__price().floatValue();
    } else {
    price = entity.price().floatValue();
    }
    var text = price.toFixed(2);
    toolView.priceValueLabel().setText(text);
    },
});
