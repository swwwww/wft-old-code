require('UIImagePickerController');
defineClass('WFTStatementSendViewController', {
    buttonPhotoPressed: function(sender) {
        var picker = UIImagePickerController.alloc().init();
        picker.setDelegate(self);
        picker.setAllowsEditing(YES);
        picker.setSourceType(0);
        self.presentViewController_animated_completion(picker, YES, null);

    },
});
