defineClass('WFTPayAViewController', {
            updateIndex: function() {
            self.setValue_forKey("0","_sectionHeader");
            self.setValue_forKey("0","_headerCellName");
            self.setValue_forKey("1","_headerCellDatetime");
            self.setValue_forKey("2","_headerNumberOfCell");

            self.setValue_forKey("1","_sectionCoupon");
            self.setValue_forKey("0","_couponCellTitle");
            self.setValue_forKey("1","_couponCellValue");
            self.setValue_forKey("2","_couponNumberOfCell");

            self.setValue_forKey("2","_sectionPay");
            self.setValue_forKey("0","_payCellTitle");
            self.setValue_forKey("1","_payCellBalance");
            if (self.gameOrderEntity().price().floatValue() == 0) {
            self.setValue_forKey("9223372036854775807","_payCellUPPay");
            self.setValue_forKey("9223372036854775807","_payCellWeiXin");
            self.setValue_forKey("9223372036854775807","_payCellAlipay");
            self.setValue_forKey("2","_payNumberOfCell");
            } else {
            self.setValue_forKey("2","_payCellUPPay");
            self.setValue_forKey("3","_payCellWeiXin");
            self.setValue_forKey("4","_payCellAlipay");
            self.setValue_forKey("5","_payNumberOfCell");
            }
            self.setValue_forKey("3","_numberOfSection");
            },
            });
