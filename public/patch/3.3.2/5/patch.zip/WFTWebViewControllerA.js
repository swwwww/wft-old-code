defineClass('WFTWebViewController', {
    webView_didReceiveServerRedirectForProvisionalNavigation: function(webView, navigation) {},
});
