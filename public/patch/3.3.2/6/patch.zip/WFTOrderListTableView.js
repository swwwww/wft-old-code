require('WFTBaseRouter');
defineClass('WFTOrderListTableView', {
    orderCommenListCelldidClickComment: function(sender) {
      var entity = sender.entity();
      var orderType = entity.order__type();
      var commentType = 2;
      var couponID = entity.coupon__id();
      var orderSn = entity.order__sn();
      var viewController = self.valueForKey("_viewController");
      if (orderType == 1) {
        commentType = 2;
      } else if (orderType == 2) {
        commentType = 7;
      } else if (orderType == 3) {
        commentType = 6;
      }
        WFTBaseRouter.shareInstance().delegate().base_goPostWithObjectId_type_ordersn(viewController, couponID, commentType, orderSn);
    },
});
