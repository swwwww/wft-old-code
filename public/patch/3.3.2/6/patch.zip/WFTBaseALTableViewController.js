// V3.3.2 P5
require('SDWebImagePrefetcher');
defineClass('WFTBaseALTableViewController', {
            viewDidAppear: function(animated) {
            self.super().viewDidAppear(animated);
            SDWebImagePrefetcher.sharedImagePrefetcher().setMaxConcurrentDownloads(100);
            },
            });
