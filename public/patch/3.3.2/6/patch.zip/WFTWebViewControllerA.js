// V3.3.2 P5
defineClass('WFTWebViewController', {
    webView_didReceiveServerRedirectForProvisionalNavigation: function(webView, navigation) {},
});
