defineClass('SDWebImageManager', {
    cacheKeyForURL: function(url) {
        if (self.cacheKeyFilter()) {
            return self.cacheKeyFilter()(url);
        } else {
            return url.absoluteString();
        }
    },
});
